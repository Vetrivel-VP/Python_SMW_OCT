# a = 10
# b = 5
# c = a + b
# print(f'{a} + {b} = {c}')
# a + b = c => 10 + 5 = 15

# a = eval(input('Enter the value for a:'))
# b = eval(input('Enter the value for b:'))
# c = a + b
# print(f'{a} + {b} = {c}')

a, b = eval(input('Enter the value of a,b:'))
print(f'{a} + {b} = {a+b}')
